<h1>Trabalho 1</h1>
<h2>Analisador léxico e sintático</h2>

<h3>Dicionário</h3>

<ul>
<li>bool: nah (one)</li>
<li>int: dul (two)</li>
<li>float: sae (three)</li>
<li>string: bello (hello)</li>
<li>char: po ka (what)</li>
<li>if: chasy (chair)</li>
<li>else: ditto (sorry)</li>
<li>loop: pwede (start)</li>
<li>break: stopa (stop)</li>
<li>return: muak (kiss)</li>
<li>print: gru (Gru)</li>
<li>scan: baboi (toy)</li>
<li>true: kan pai (cheers)</li>
<li>false: bee do (fire)</li>
</ul>